import { test, expect } from '@playwright/test';
import { HomePage } from '../pages/home.page';
import { ProductPage } from '../pages/product.page';
import { CartPage } from '../pages/cart.page';
import { CheckoutPage } from '../pages/checkout.page';
import { ConfirmationPage } from '../pages/confirmation.page';
import users from '../fixtures/users.json';

test.describe('E2E purchase', () => {
  for (const user of users) {
    test(`purchase flow for ${user.email}`, async ({ page }) => {
      const home = new HomePage(page);
      const product = new ProductPage(page);
      const cart = new CartPage(page);

      await home.goto();
      // Register (simple flow)
    // Register (simple flow)
    await page.click('text=Register');
    await page.check('input#gender-female');
    await page.fill('#FirstName', 'Yusraa');
    await page.fill('#LastName', 'Atifff');
    await page.fill('#Email', user.email);
    await page.fill('#Password', user.password);
    await page.fill('#ConfirmPassword', user.password);
    await page.click('#register-button');

    // Wait for success and go back to home
    await page.waitForSelector('text=Your registration completed');
    await page.click('text=Continue');

    // Click Continue to go back to homepage
//       await page.click('text=Continue');
//       // Login
//       await page.click('text=Log in');
//       await page.fill('#Email', user.email);
//       await page.fill('#Password', user.password);
//       await page.click('input[value="Log in"]');

      // Navigate and add product
      await home.navigateToNotebooks();
      await home.goto();
      await product.selectProductByName('14.1-inch Laptop');
//       await product.selectProductByXpath('/html/body/div[4]/div[1]/div[2]/ul[1]/li[2]/ul/li[2]/a'); // exact product name
// //       await page.click('xpath=/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[3]/div/div/div[2]/div[3]/div[2]/input');
//         await product.selectProductByXpath('/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[3]/div/div/div[2]/div[3]/div[2]/input');
      const prodName = await product.getProductName();
      const prodPrice = await product.getProductPrice();
      await product.addToCart();

      // Verify cart badge quantity
      const badge = await page.textContent('.cart-qty'); // e.g., "(1)"
      expect(badge).toContain('1');

      // Go to cart and verify product and price
//       // Go to Shopping cart first
//         await page.click('a[href="/cart"]');

        // Wait for the Shopping cart page
          await page.click('text=Shopping cart');
          const cartName = await cart.getCartProductName();
          const cartPrice = await cart.getCartProductPrice();
          expect(cartName).toContain(prodName);
          expect(cartPrice).toContain(prodPrice);
//       await page.click('text=Shopping cart');
//       const cartName = await cart.getCartProductName();
//       const cartPrice = await cart.getCartProductPrice();
//       expect(cartName).toBe(prodName);
//       expect(cartPrice).toBe(prodPrice);

      // Proceed to checkout: fill billing, shipping, payment (dummy)
      await cart.checkout();
      await page.fill('#BillingNewAddress_FirstName','Test');
      await page.fill('#BillingNewAddress_LastName','User');
      await page.fill('#BillingNewAddress_Email', user.email);
      // fill address fields...
      await page.click('input[title="Continue"]'); // shipping steps, payment steps
      // Complete order
      await page.click('input[title="Confirm"]');
      // Validate thank you page and order number
      await expect(page.locator('text=Thank you')).toBeVisible();
      const orderNum = await page.textContent('.order-number'); // adjust selector
      expect(orderNum).toMatch(/Order number: \d+/);
    });
  }
});
