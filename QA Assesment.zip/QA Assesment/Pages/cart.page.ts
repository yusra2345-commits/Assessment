import { Page } from '@playwright/test';

export class CartPage {
  readonly page: Page;

  constructor(page: Page) {
    this.page = page;
  }

  async getCartProductName() {
    return await this.page.textContent('.product-name a');
  }

  async getCartProductPrice() {
    return await this.page.textContent('.product-unit-price');
  }

  async checkout() {
    await this.page.click('button#checkout');
    await this.page.waitForTimeout(10000); // 1 second delay before hover

  }
}
