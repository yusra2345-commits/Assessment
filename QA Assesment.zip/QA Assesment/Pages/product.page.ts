import { Page } from '@playwright/test';

export class ProductPage {
  readonly page: Page;

  constructor(page: Page) {
    this.page = page;
  }

  async selectProductByName(name: string) {
    await this.page.click(`text=${name}`);
  }

  async getProductName() {
    return await this.page.textContent('h1');
  }

  async getProductPrice() {
    return await this.page.textContent('.product-price');
  }

  async addToCart() {
    await this.page.click('input#add-to-cart-button-31');
    await this.page.waitForTimeout(10000); // 1 second delay before hover
// Adjust if ID changes
  }
}
