import { Page } from '@playwright/test';

export class CheckoutPage {
  readonly page: Page;

  constructor(page: Page) {
    this.page = page;
  }

  async waitForCheckoutPage() {
    await this.page.waitForSelector('h1:has-text("Checkout")');
  }

  async fillBillingAddress(email: string) {
    await this.page.waitForSelector('#BillingNewAddress_FirstName');
    await this.page.fill('#BillingNewAddress_FirstName', 'Test');
    await this.page.fill('#BillingNewAddress_LastName', 'User');
    await this.page.fill('#BillingNewAddress_Email', email);
    await this.page.selectOption('#BillingNewAddress_CountryId', '1');
    await this.page.fill('#BillingNewAddress_City', 'New York');
    await this.page.fill('#BillingNewAddress_Address1', '123 Test Street');
    await this.page.fill('#BillingNewAddress_ZipPostalCode', '10001');
    await this.page.fill('#BillingNewAddress_PhoneNumber', '1234567890');
  }

  async clickContinueButton(sectionName: string) {
    await this.page
      .locator(
        `div#${sectionName}-buttons-container input.button-1, input.button-1.new-address-next-step-button`
      )
      .first()
      .click();
  }

  async completeCheckout(email: string) {
    await this.waitForCheckoutPage();
    await this.fillBillingAddress(email);

    await this.clickContinueButton('billing');
    await this.page.waitForSelector('#shipping-buttons-container input.button-1');
    await this.clickContinueButton('shipping');
    await this.page.waitForSelector('#shipping-method-buttons-container input.button-1');
    await this.clickContinueButton('shipping-method');
    await this.page.waitForSelector('#payment-method-buttons-container input.button-1');
    await this.clickContinueButton('payment-method');
    await this.page.waitForSelector('#payment-info-buttons-container input.button-1');
    await this.clickContinueButton('payment-info');
    await this.page.waitForSelector('#confirm-order-buttons-container input.button-1');
    await this.page.click('#confirm-order-buttons-container input.button-1');
  }
}
