import { Page } from '@playwright/test';

export class HomePage {
  readonly page: Page;

  constructor(page: Page) {
    this.page = page;
  }

  async goto() {
    await this.page.goto('https://demowebshop.tricentis.com/');
  }

//   async navigateToNotebooks() {
//     await this.page.click('text=Computers');
//     await this.page.click('text=Notebooks');
    async navigateToNotebooks() {
  // Hover over Computers to reveal dropdown
    await this.page.hover('text=Computers');

  // Wait for Notebooks to become visible
    await this.page.waitForSelector('text=Notebooks', { state: 'visible', timeout: 10000 });

  // Now click Notebooks
    await this.page.click('text=Notebooks');
  }
   // Step 3: click Shopping cart link in header
    async navigateToShoppingcart() {
    // Wait for header link to be visible and clickable
    await this.page.click('text=Shopping cart');
//     await this.page.waitForSelector('#topcartlink > a', { state: 'visible' });
    await this.page.click('#topcartlink > a');
  }

  // Step 4: click Add to Cart for 14.1-inch Laptop (or any product)
  async clickAddToCart() {
    // You can use a more specific XPath for the "14.1-inch Laptop" card
    await this.page.click(
      'xpath=//div[@class="details"]/a[contains(text(),"14.1-inch Laptop")]/../../div[@class="add-info"]//input[@value="Add to cart"]'
    );

    // Wait for success message and let it disappear before proceeding
    await this.page.waitForSelector('.bar-notification.success', { state: 'visible' });
    await this.page.waitForSelector('.bar-notification.success', { state: 'hidden' });
  }

}
