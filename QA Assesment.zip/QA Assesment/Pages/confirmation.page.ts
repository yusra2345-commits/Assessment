import { Page, expect } from '@playwright/test';

export class ConfirmationPage {
  readonly page: Page;

  constructor(page: Page) {
    this.page = page;
  }

  async waitForThankYouPage() {
    await this.page.waitForSelector('h1:has-text("Thank you")');
  }

  async getOrderNumber() {
    await this.page.waitForSelector('.order-number');
    const orderText = await this.page.textContent('.order-number');
    return orderText?.trim() || '';
  }

  async verifyOrderSuccess() {
    await this.waitForThankYouPage();
    const orderText = await this.getOrderNumber();
    expect(orderText).toMatch(/Order number:/);
  }

  async clickContinue() {
    await this.page.click('input.button-1.order-completed-continue-button');
  }
}
